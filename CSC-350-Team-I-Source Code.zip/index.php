<?php
include_once 'db-connect.php';

$getCourseDataSql = "SELECT * FROM courses ORDER BY course_no";

if ( ! $getCourseQuery = mysqli_query($conn, $getCourseDataSql)) {
    die("Error : " . mysqli_error($conn));
} else {
    $courses = mysqli_fetch_all($getCourseQuery, MYSQLI_ASSOC);
};

$getSectionDataSql = "SELECT * FROM sections ";
$getSectionDataSql .= "LEFT JOIN courses ON sections.course_id = courses.id ORDER BY courses.course_no";

if ( ! $getSectionDataQuery = mysqli_query($conn, $getSectionDataSql)) {
    die("Error : " . mysqli_error($conn));
} else {
    $sections = mysqli_fetch_all($getSectionDataQuery, MYSQLI_ASSOC);
};

$getRoomDataSql = "SELECT * FROM rooms ";

if ( ! $getRoomDataQuery = mysqli_query($conn, $getRoomDataSql)) {
    die("Error : " . mysqli_error($conn));
} else {
    $rooms = mysqli_fetch_all($getRoomDataQuery, MYSQLI_ASSOC);
};

?>

<html>
<head>
	<title> Term Scheduling </title>
</head>
<body>
<h1>Term Scheduling</h1>
<table width="40%">
	<tr>
		<td><a href="upload.php">Upload Files</a></td>
		<td><a href="generate-schedule.php">Generate Schedule</a></td>
		<td><a href="schedule-list.php">View Schedule List</a></td>
		<td><a href="schedule-grid.php">View Schedule Grid 1</a></td>
		<td><a href="schedule-grid-2.php">View Schedule Grid 2</a></td>
	</tr>
</table>





<!--List of all Courses in database-->
<h2> Courses List </h2>
<?php if ( ! empty($courses)) { ?>
	<table border="1">
		<tr>
			<th>Course No.</th>
			<th>Total Course Duration</th>
		</tr>

      <?php foreach ($courses as $course) { ?>
				<tr align="center">
					<td><?php echo $course['course_no'] ?></td>
					<td><?php echo $course['hours'] ?></td>
				</tr>
      <?php } ?>
	</table>
<?php } else { ?>
	No Courses in database
<?php } ?>
<!--Courses List End Here!-->

<!--List of all sections in database-->
<h2> Section List </h2>
<?php if ( ! empty($sections)) { ?>
	<table border="1">
		<tr>
			<th>Course No.</th>
			<th>Section No.</th>
			<th>Total Meeting Days</th>
		</tr>

      <?php foreach ($sections as $section) { ?>
				<tr align="center">
					<td><?php echo $section['course_no'] ?></td>
					<td><?php echo $section['section_no'] ?></td>
					<td><?php echo $section['no_of_days'] ?></td>
				</tr>
      <?php } ?>
	</table>
<?php } else { ?>
	No Section in database.
<?php } ?>

<!--Section List End Here!-->

<!--List of all Rooms in database-->
<h2> Room List </h2>
<?php if ( ! empty($rooms)) { ?>
	<table border="1">
		<tr>
			<th>Room No.</th>
		</tr>

      <?php foreach ($rooms as $room) { ?>
				<tr align="center">
					<td><?php echo $room['room_no'] ?></td>
				</tr>
      <?php } ?>
	</table>
<?php } else { ?>
	No Rooms in database.
<?php } ?>
<!--Room List End Here!-->
</body>
</html>

<?php
	include 'db-close.php';
?>
	