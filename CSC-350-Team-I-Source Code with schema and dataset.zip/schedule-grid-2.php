<?php

include_once "db-connect.php";

$getRoomsSql = "select * from rooms ";

if ( ! $getRoomsQuery = mysqli_query($conn, $getRoomsSql)) {
    die("Error:" . mysqli_error($conn));
} else {
    $rooms = mysqli_fetch_all($getRoomsQuery, MYSQLI_ASSOC);
}
if(isset($_GET['room'])){
    $roomId      = $_GET['room'];
}else{
	$roomId = 0;
}

$scheduleSql = "SELECT ";
$scheduleSql .= "courses.course_no as courseNo,";
$scheduleSql .= "sections.section_no as sectionNo,";
$scheduleSql .= "rooms.room_no as roomNo,";
$scheduleSql .= "ts.start_time as startTime,";
$scheduleSql .= "sum(ts.duration)as duration,";
$scheduleSql .= "ts.day as MeetingDay ";
$scheduleSql .= "FROM time_slot ts ";
$scheduleSql .= "JOIN rooms on ts.room_id = rooms.id ";
$scheduleSql .= "JOIN sections on ts.section_id = sections.id ";
$scheduleSql .= "JOIN courses on sections.course_id=courses.id ";

if ($roomId) {
    $scheduleSql .= "WHERE ts.room_id =" . $roomId . " ";
}

//$scheduleSql .= "AND ts.section_id is not null ";
$scheduleSql .= "GROUP by courses.id, ts.section_id, ts.day ";
$scheduleSql .= "ORDER BY ts.start_time";


if ( ! $output = mysqli_query($conn, $scheduleSql)) {
    die('Error: ' . mysqli_error($conn));
};

$timeTable = mysqli_fetch_all($output, MYSQLI_ASSOC);


foreach ($timeTable as $data) {
    $endTime                                               = strtotime('+' . '60' * $data['duration'] . 'minutes', strtotime($data['startTime']));
    $data['endTime']                                       = date('H:i', $endTime);
    $timeTableData[$data['roomNo']][$data['MeetingDay']][] = $data;
}


?>

<html>
<head>
	<title> Term Scheduling </title>
</head>
<body>
<h1>Term Scheduling</h1>
<a href="index.php">Go Back To Home</a></br></br>
<h2>Schedule</h2>

<form method='GET' enctype='multipart/form-data'>

	Show schedule for room :
	<select name="room">
		<option value="0">All</option>
      <?php foreach ($rooms as $room) { ?>
				<option value="<?php echo $room['id'] ?>" <?php echo isset($roomId) && $room['id'] == $roomId ? 'selected' : '' ?>><?php echo $room['room_no'] ?></option>
      <?php } ?>
	</select>

	<button type='submit'>Submit:</button>
</form>

<?php
$days = [ 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday' ];
?>

<?php if ( ! empty($timeTableData)) { ?>
	<table style="width:100%; border: 1px black" border="1">
		<tr>
			<th>&#8595;ROOM\DAY &#8594;</th>
        <?php foreach ($days as $day) { ?>
					<th><?php echo $day ?></th>
        <?php } ?>
		</tr>
      <?php foreach ($timeTableData as $roomNo => $data) { ?>
				<tr align="center">
					<td><?php echo $roomNo ?></td>
            <?php foreach ($days as $day) { ?>
							<td>
                  <?php if (array_key_exists($day, $data)) { ?>
										<ul style="padding: 0">
                        <?php foreach ($data[$day] as $class) { ?>
													<li style="border: 1px solid black; list-style: none; padding: 0">
														<p><?php echo $class['startTime'] . "-" . $class['endTime'] ?></p>
														<p><?php echo $class['courseNo'] . "-" . $class['sectionNo'] ?></p>
													</li>
                        <?php } ?>
										</ul>

                  <?php } else { ?>
										-
                  <?php } ?>
							</td>
            <?php } ?>
				</tr>
      <?php } ?>
	</table>

<?php } else { ?>
    <?php if (isset($_GET['room']) && $_GET['room']) { ?>
		No schedule found.
    <?php } else { ?>
		Select a room to view schedule
    <?php } ?>
<?php } ?>

</body>
</html>

<?php
include_once 'db-close.php';
?>
