<?php
include_once 'db-connect.php';
include_once 'upload-data.php';

?>

<html>
<head>
    <title> Term Scheduling </title>
</head>
<body>
<h1>Term Scheduling</h1>
<a href="index.php">GO Back To Home</a>
<h2>Upload Files</h2>
<p><b>Note : </b> All previous data will be erased(if there is any).</p>
<form method='POST' enctype='multipart/form-data'>
    <p> Courses:<input type='file' name='courses' />
    <p> Rooms:<input type='file' name='rooms' />
    <p> Upload: <input type='submit' name='submit' value='Upload' /></p>
</form>

<!--Room List End Here!-->
</body>
</html>
