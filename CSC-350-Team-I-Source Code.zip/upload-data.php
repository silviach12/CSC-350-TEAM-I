<?php
/*
 * This code in this file takes csv file as input and populate the database using the data in the given csv file.
 */

if (isset($_POST['submit'])) {
    //Courses And Section import from courses.csv

    if ($_FILES['courses']['name']) {
        $emptyCourses = "DELETE FROM courses";
        if ( ! $emptyCoursesQuery = mysqli_query($conn, $emptyCourses)) {
            die("Error:" . mysqli_error($conn));
        };

        $emptyCourses = "DELETE FROM sections";
        if ( ! $emptyCoursesQuery = mysqli_query($conn, $emptyCourses)) {
            die("Error:" . mysqli_error($conn));
        };

        $arrFileName = explode('.', $_FILES['courses']['name']); //reading file
        if ($arrFileName[1] == 'csv') {
            $handle  = fopen($_FILES['courses']['tmp_name'], "r"); //opening file
            $courses = [];

            //Grouping section according to courses
            while (($data = fgetcsv($handle)) !== false) {
                $courses[$data[0]][] = $data;
            }

            fclose($handle);

            foreach ($courses as $courseName => $sections) {
                //Assigning hours to courses
                if ($courseName == 'CSC101') {
                    $hours = 4;
                } else {
                    $hours = 5;
                }


                //Inserting courses into database

                $insertCourseSql = "INSERT INTO courses(course_no,hours) values('" . $courseName . "','" . $hours . "')";
                if ( ! $coursesQuery = mysqli_query($conn, $insertCourseSql)) {
                    die("Error:" . mysqli_error($conn));
                };


                $courseId = mysqli_insert_id($conn);

                //Inserting of each courses into database
                foreach ($sections as $section) {

                    $sectionNo        = rand(1000, 2000); // Randomly generating a section no
                    $insertSectionSql = "INSERT INTO sections(course_id, section_no, no_of_days) ";
                    $insertSectionSql .= "VALUES('" . $courseId . "','" . $sectionNo . "','" . $section[1] . "')";

                    if ( ! $sectionQuery = mysqli_query($conn, $insertSectionSql)) {
                        echo "Error:" . mysqli_error($conn);
                    };

                }
            }
        }
        echo "Courses file is imported successfully!<br>";
    }



    //Room Import from rooms.csv
    if ($_FILES['rooms']['name']) {

        $arrFileName = explode('.', $_FILES['rooms']['name']);
        $emptyRooms = "DELETE FROM rooms";
        if ( ! $emptyRoomsQuery = mysqli_query($conn, $emptyRooms)) {
            die("Error:" . mysqli_error($conn));
        };

        if ($arrFileName[1] == 'csv') {
            $handle = fopen($_FILES['rooms']['tmp_name'], "r");
            while (($data = fgetcsv($handle)) !== false) {
                //Check room data with same name to prevent duplication of room
                $getRoomSql = "SELECT * FROM rooms WHERE room_no = '" . $data[0] . "'";
                if ( ! $getRoomQuery = mysqli_query($conn, $getRoomSql)) {
                    echo "Error:" . mysqli_error($conn);
                }else{
                    if(!mysqli_num_rows($getRoomQuery) > 0){ // if no room exist with same name
                        //Insert Rooms into database
                        $insertRoomSql = "INSERT INTO rooms(room_no) VALUES('" . $data[0] . "')";
                        if ( ! $insertRoomQuery = mysqli_query($conn, $insertRoomSql)) {
                            echo "Error:" . mysqli_error($conn);
                        };
                    }
                };
            }

            fclose($handle);
            echo "Rooms file is imported successfully!<br>";
        }
    }
}

?>