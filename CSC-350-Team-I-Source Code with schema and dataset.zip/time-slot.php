<?php
/*
 * This code in this file creates time slots of 1 hour duration for each day of week for each room.
 * Since the each time slot has a duration of 1 hour, a class is required to have a minimum duration of 1 hour
 * and the  duration of class can only be increased in a increment of an hour.
 */


// Empty Time Slots Table
$empySlotsSql = "DELETE FROM time_slot";
if ( ! $query = mysqli_query($conn, $empySlotsSql)) {
    echo "Error: " . mysqli_error($conn);
}

// Fetching all rooms from database.
$getRoomsSql = "Select * from rooms";

if (!$getRoomsQuery = mysqli_query($conn, $getRoomsSql)) {
    echo "Error: " . mysqli_error($conn);
} else {
    $rooms = mysqli_fetch_all($getRoomsQuery, MYSQLI_ASSOC);
}

//Array of all the days in a week
$days = [ 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday' ];

// Creating time slot of 1 hr for each room for all days in a week"
foreach ($rooms as $room) {
    foreach ($days as $day) {
        $start   = strtotime("9:00");
        $end     = strtotime("21:00");
        $current = $start;

        while ($current < $end) {
            $sTime   = date('H:i', $current);
            $current = strtotime('+60 minutes', $current);
            $eTime   = date('H:i', $current);
            $data    = [
                'room_id'  => $room['id'],
                'day'      => $day,
                'start'    => $sTime,
                'end'      => $eTime,
                'duration' => 1
            ];

            $insertRoomSlotSql = "insert into time_slot(room_id,start_time,day,end_time,duration)";
            $insertRoomSlotSql .= "values('" . $data['room_id'] . "','" . $data['start'] . "','" . $data['day'] . "','" . $data['end'] . "','" . $data['duration'] . "')";

            if(!$insertRoomSlotQuery = mysqli_query($conn, $insertRoomSlotSql)){
                echo "Error: " . mysqli_error($conn);
            };
        }
    }
}


?>