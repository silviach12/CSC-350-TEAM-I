<?php

include_once 'config.php';
// Create connection
$conn= new mysqli($servername,$username, "",$dbname);
if($conn->connect_error)
{
die("Connection failed:". $conn->connect_error);
}