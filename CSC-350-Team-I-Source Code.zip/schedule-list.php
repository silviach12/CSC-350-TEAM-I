<?php

include_once "db-connect.php";

$scheduleSql = "SELECT ";
$scheduleSql .= "courses.course_no as courseNo,";
$scheduleSql .= "sections.section_no as sectionNo,";
$scheduleSql .= "rooms.room_no as roomNo,";
$scheduleSql .= "time_slot.start_time as startTime,";
$scheduleSql .= "sum(time_slot.duration)as duration,";
$scheduleSql .= "time_slot.day as MeetingDay ";
$scheduleSql .= "FROM time_slot ";
$scheduleSql .= "JOIN rooms on time_slot.room_id = rooms.id ";
$scheduleSql .= "JOIN sections on time_slot.section_id = sections.id ";
$scheduleSql .= "JOIN courses on sections.course_id=courses.id ";
$scheduleSql .= "GROUP by courses.id, sections.id, time_slot.day ";
$scheduleSql .= "ORDER BY time_slot.section_id";


if ( ! $scheduleQuery = mysqli_query($conn, $scheduleSql)) {
    echo "Error: " . mysqli_error($conn);
} else {
    $list = mysqli_fetch_all($scheduleQuery, MYSQLI_ASSOC);
}

?>
<html>
<head>
	<title> Term Scheduling </title>
</head>
<body>
<h1>Term Scheduling</h1>
<a href="index.php">Go Back To Home</a></br></br>

<h2> All Schedule List</h2>

<?php if ( ! empty($list)) { ?>
	<table border='1' width="100%">
		<tr>
			<th> Course No.</th>
			<th> Section No.</th>
			<th> Room No.</th>
			<th> Duration(in hours)</th>
			<th> Meeting Day</th>
			<th> Start Time</th>
			<th> End Time</th>

		</tr>
      <?php foreach ($list as $data) { ?>
				<tr align="center">
					<td><?php echo $data['courseNo'] ?> </td>
					<td><?php echo $data['sectionNo'] ?></td>
					<td><?php echo $data['roomNo'] ?></td>
					<td><?php echo $data['duration'] ?></td>
					<td><?php echo $data['MeetingDay'] ?></td>
					<td><?php echo $data['startTime'] ?></td>
					<td>
              <?php
              $endTime = strtotime('+' . '60' * $data['duration'] . 'minutes', strtotime($data['startTime']));
              echo date('H:i', $endTime);
              ?>
					</td>
				</tr>
      <?php } ?>

	</table>
<?php } else { ?>
		No schedule found. Please generate the schedule from homepage.
<?php } ?>
</body>
</html>
