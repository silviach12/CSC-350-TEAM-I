<?php
include_once 'db-connect.php';


$getCourseCountSql = "SELECT * FROM courses";
if(!$getCourseCountQuery = mysqli_query($conn, $getCourseCountSql)){
    die("Error: " . mysqli_error($conn));
}else{
    $courseCount = mysqli_num_rows($getCourseCountQuery);

    if($courseCount < 1){
        echo ("No Courses data found in database. Please upload the data first.<br>");
    }
};

$getSectionCountSql = "SELECT * FROM sections";
if(!$getSectionCountQuery = mysqli_query($conn, $getSectionCountSql)){
    die("Error: " . mysqli_error($conn));
}else{
    $sectionCount = mysqli_num_rows($getSectionCountQuery);
    if($sectionCount < 1){
        echo "No Sections data found in database. Please upload the data first.<br>";
    }
};

$getRoomCountSql = "SELECT * FROM rooms";
if(!$getRoomCountQuery = mysqli_query($conn, $getRoomCountSql)){
    die("Error: " . mysqli_error($conn));
}else{
    $roomCount = mysqli_num_rows($getRoomCountQuery);
    if($roomCount < 1){
        echo "No Rooms data found in database. Please upload the data first.<br>";
    }
};

if($courseCount && $sectionCount && $roomCount){
    include_once 'time-slot.php';
    include_once 'schedule.php';
}


?>

<html>
<head>
    <title> Term Scheduling </title>
</head>
<body>
<h1>Term Scheduling</h1>
<a href="index.php">Go Back To Home</a>
</body>
</html>

<?php
include_once 'db-close.php';
?>
