<?php

include_once "db-connect.php";

$getRoomsSql = "select * from rooms ";

if ( ! $getRoomsQuery = mysqli_query($conn, $getRoomsSql)) {
    die("Error:" . mysqli_error($conn));
} else {
    $rooms = mysqli_fetch_all($getRoomsQuery, MYSQLI_ASSOC);
}

if (isset($_GET['room']) && $_GET['room']) {
    $roomId      = $_GET['room'];
    $scheduleSql = "SELECT ";
    $scheduleSql .= "courses.course_no as courseNo,";
    $scheduleSql .= "sections.section_no as sectionNo,";
    $scheduleSql .= "time_slot.start_time as startTime,";
    $scheduleSql .= "time_slot.day as MeetingDay ";
    $scheduleSql .= "FROM time_slot ";
    $scheduleSql .= "JOIN rooms on time_slot.room_id = rooms.id ";
    $scheduleSql .= "LEFT JOIN sections on time_slot.section_id = sections.id ";
    $scheduleSql .= "LEFT JOIN courses on sections.course_id=courses.id ";
    $scheduleSql .= "WHERE time_slot.room_id =" . $roomId . " ";
    $scheduleSql .= "ORDER BY time_slot.start_time";

    if ( ! $output = mysqli_query($conn, $scheduleSql)) {
        die('Error: ' . mysqli_error($conn));
    };

    $timeTable = mysqli_fetch_all($output, MYSQLI_ASSOC);

    //Formatting data
    foreach ($timeTable as $data) {
        $ftable[$data['startTime']][$data['MeetingDay']] = $data;
    }
}


?>

<html>
<body>
<h1>Term Scheduling</h1>
<a href="index.php">Go Back To Home</a></br></br>
<form method='GET' enctype='multipart/form-data'>

	Show schedule for room :
	<select name="room">
		<option></option>
      <?php foreach ($rooms as $room) { ?>
				<option value="<?php echo $room['id'] ?>" <?php echo isset($roomId) && $room['id'] == $roomId ? 'selected' : '' ?>><?php echo $room['room_no'] ?></option>
      <?php } ?>
	</select>

	<button type='submit'>Submit:</button>
</form>

<?php
$days = [ 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday' ];

$start   = strtotime("9:00");
$end     = strtotime("21:00");
$current = $start;

while ($current < $end) {
    $times[] = date('H:i:s', $current);
    $current = strtotime('+60 minutes', $current);
}


?>

<?php if ( ! empty($ftable)) { ?>
	<table border="1" width="100%" height="1000px">
		<tr>
			<th>&#8595;TIME\DAY &#8594;</th>
        <?php foreach ($days as $day) { ?>
					<th><?php echo $day ?></th>
        <?php } ?>
		</tr>

      <?php foreach ($times as $time) { ?>
				<tr align="center">
					<td rowspan="2"><?php echo $time . " - " . date('H:i:s', strtotime('+60 minutes', strtotime($time))); ?></td>
            <?php foreach ($days as $day) { ?>
							<td rowspan="2"><?php echo $ftable[$time][$day]['courseNo'] . '-' . $ftable[$time][$day]['sectionNo'] ?> </td>
            <?php } ?>
				</tr>
				<tr>
				</tr>
      <?php } ?>
	</table>
<?php } else { ?>
    <?php if (isset($_GET['room']) && $_GET['room']) { ?>
			No schedule found. Please generate it from the homepage.
    <?php } else { ?>
			Select a room to view schedule
    <?php } ?>
<?php } ?>

</body>
</html>

<?php
include_once 'db-close.php';
?>
