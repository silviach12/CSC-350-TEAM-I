<?php

/*
 * This code in this file generates schedule by finding available time slot and assigning them to section.
 */


////Empty All Time Slots
//$emptySql = "UPDATE time_slot SET section_id = null WHERE section_id is not null";
//
//if ( ! $emptyQuery = mysqli_query($conn, $emptySql)) {
//    echo "Error: " . mysqli_error($conn);
//}


//Fetching all section from database
$getSectionsSql = "SELECT ";
$getSectionsSql .= "sections.id AS section_id, sections.section_no AS section_no,courses.hours, sections.no_of_days "; // Selection of required columns only
$getSectionsSql .= "FROM sections ";
$getSectionsSql .= "JOIN courses ON sections.course_id=courses.id"; // Join course to get course name and course hours

if ( ! $getSectionQuery = mysqli_query($conn, $getSectionsSql)) {
    echo "Error: " . mysqli_error($conn);
} else {
    $sections = mysqli_fetch_all($getSectionQuery, MYSQLI_ASSOC);
};


// Creating a array of class so that they can be scheduled
foreach ($sections as $section) {
    $totalHours = $section['hours'];
    $no_of_days = $section['no_of_days'];
    //    $daysSql       = "select distinct t.day, t.room_id, sum(t.duration) 'sum' from time_slot t where section_id is null group by t.day,t.room_id HAVING sum > " . $totalHours . " ORDER BY RAND(),t.room_id LIMIT " . $no_of_days;

    // Getting available days for scheduling class to
    $daysSql = "SELECT ";
    $daysSql .= "DISTINCT ts.day, ts.room_id, sum(ts.duration) 'sum' ";
    $daysSql .= "FROM time_slot ts ";
    $daysSql .= "WHERE section_id is null ";
    $daysSql .= "GROUP BY ts.day,ts.room_id ";
    $daysSql .= "HAVING sum > " . $totalHours . " ";
    $daysSql .= "ORDER BY RAND(),ts.room_id LIMIT " . $no_of_days;

    if ( ! $dayQuery = mysqli_query($conn, $daysSql)) {
        die("Error:" . mysqli_error($conn));
    } else {
        $daysToBeScheduledCount = mysqli_num_rows($dayQuery);
        $daysToBeScheduled      = mysqli_fetch_all($dayQuery, MYSQLI_ASSOC);
    };

    $mod     = $totalHours % $no_of_days; //check if class hour can be equally divided or split into class days
    $classes = [];

    if ($daysToBeScheduledCount < $no_of_days) { // Check of there is enough days available to assign time slot
        echo "Cannot find appropriate time slot for section - " . $section['section_no'] . "</br>";
    } else {    // if enough time slot is available
        //If the total hours cannot be equally split for each days
        if ($mod) {
            $remainingDays = $no_of_days - $mod;
            $remainingHour = floor($totalHours / $no_of_days);

            for ($i = 0; $i < $no_of_days; $i ++) {
                if ($i >= $remainingDays) {
                    $classes[] = [
                        'section_id' => $section['section_id'],
                        'day'        => $daysToBeScheduled[$i]['day'],
                        'hour'       => $remainingHour + 1,
                        'room_id'    => $daysToBeScheduled[$i]['room_id']
                    ];
                } else {

                    $classes[] = [
                        'section_id' => $section['section_id'],
                        'day'        => $daysToBeScheduled[$i]['day'],
                        'hour'       => $remainingHour,
                        'room_id'    => $daysToBeScheduled[$i]['room_id']
                    ];
                }
            }
            // If the class hours can be equally split into days
        } else {
            for ($i = 0; $i < $no_of_days; $i ++) {
                $classes[] = [
                    'section_id' => $section['section_id'],
                    'day'        => $daysToBeScheduled[$i]['day'],
                    'hour'       => $totalHours / $no_of_days,
                    'room_id'    => $daysToBeScheduled[$i]['room_id']
                ];
            }

        }
    }

    // Scheduling the classes by assigning them to time slots
    foreach ($classes as $class) {
        $timeSlotSql = "SELECT ts.id, (SELECT sum(duration) from time_slot WHERE ID <= ts.id AND  day=ts.day AND section_id is null AND room_id=ts.room_id) 'total' FROM time_slot ts ";
        $timeSlotSql .= "WHERE ts.day='" . $class['day'] . "' AND ts.section_id is null AND ts.room_id =" . $class['room_id'] . " HAVING total <= " . $class['hour'];
        $result2     = mysqli_query($conn, $timeSlotSql);
        $timeSlots   = mysqli_fetch_all($result2, MYSQLI_ASSOC);

        $slotIds = array_column($timeSlots, 'id');
        $slotIds = implode(',', $slotIds);

        $sql    = "UPDATE time_slot SET section_id= '" . $class['section_id'] . "'where id in (" . $slotIds . ")";
        $update = mysqli_query($conn, $sql);
    }


}

echo "Schedule has been generated. Go back to home to view schedule";
?>